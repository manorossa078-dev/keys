#!/usr/bin/env python3
_H='SELECT * FROM keys'
_G='Access denied.'
_F='ADMIN_PASSWORD'
_E='ADMIN_USERNAME'
_D='Enter your administrator password: '
_C='Enter your administrator username: '
_B='.settings/settings.env'
_A='settings/.key'
import sqlite3
from pwinput import pwinput
import os
from dotenv import load_dotenv,set_key
from getpass import getpass
from cryptography.fernet import Fernet
from argon2 import PasswordHasher
from argon2.exceptions import VerifyMismatchError
conn=sqlite3.connect('app.db')
cur=conn.cursor()
__ph=PasswordHasher(time_cost=3,memory_cost=65536,parallelism=4)
if not os.path.exists(_A):
	key=Fernet.generate_key()
	with open(_A,'wb')as f:f.write(key)
	with open(_A,'rb')as f:key=f.read();encrypter=Fernet(key)
else:
	with open(_A,'rb')as f:key=f.read()
	encrypter=Fernet(key)
load_dotenv(_B)
CMDS=['exit','newKey','viewKey','deleteKey','version','viewAll']
VER='v0.0.3'
ROOT_USERNAME=os.getenv(_E)
ROOT_PASSWORD=os.getenv(_F)
def hasher(psw):return __ph.hash(psw)
def verify(stored,psw):
	try:__ph.verify(stored,psw);return True
	except VerifyMismatchError:return False
cur.execute('\nCREATE TABLE IF NOT EXISTS keys(\n    idKey INTEGER PRIMARY KEY AUTOINCREMENT,\n    keyUser VARCHAR(100) NOT NULL,\n    details TEXT,\n    key VARCHAR(255) NOT NULL\n)\n')
conn.commit()
if ROOT_USERNAME is None:rootUsername=input(_C);rootPassword=pwinput(prompt=_D);set_key(_B,_E,hasher(rootUsername));set_key(_B,_F,hasher(rootPassword))
while True:
	print(f"\n{CMDS}\n");cmd=input('Enter your command: ')
	if cmd==CMDS[0]:break
	elif cmd==CMDS[1]:username=input("Enter the key's owner's name: ");details=input('Enter the details of said key (not necessary): ')or None;key=pwinput(prompt='Enter your key: ',mask='*');cur.execute('INSERT INTO keys(keyUser, details, key) VALUES(?, ?, ?)',(username,details,encrypter.encrypt(key.encode()).decode()));conn.commit()
	elif cmd==CMDS[2]:
		usrnm=input(_C);passwd=getpass(_D)
		if verify(ROOT_USERNAME,usrnm)and verify(ROOT_PASSWORD,passwd):
			verifyID=int(input('Key ID: '));cur.execute('SELECT idKey FROM keys');ids=[A[0]for A in cur.fetchall()]
			if verifyID in ids:cur.execute('SELECT key FROM keys WHERE idKey = ?',(verifyID,));print(encrypter.decrypt(cur.fetchone()[0]).decode())
			else:print('ID not found.')
		else:print(_G)
	elif cmd==CMDS[3]:
		usrnm=input(_C);passwd=getpass(_D)
		if verify(ROOT_USERNAME,usrnm)and verify(ROOT_PASSWORD,passwd):cur.execute(_H);print(cur.fetchall());idToDelete=input('Enter the key you want to delete: ');cur.execute('DELETE FROM keys WHERE idKey = ?',(idToDelete,));conn.commit()
		else:print(_G)
	elif cmd==CMDS[4]:print(VER)
	elif cmd==CMDS[5]:cur.execute(_H);print(cur.fetchall())
	else:print('Command was not recognized. Try with another one.')
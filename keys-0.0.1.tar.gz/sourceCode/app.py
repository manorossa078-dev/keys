#!/usr/bin/env python3
_H='ID not found.'
_G='viewAll'
_F='version'
_E='deleteKey'
_D='viewKey'
_C='newKey'
_B=False
_A=None
import os,sqlite3,sys
from argon2 import PasswordHasher
from argon2.exceptions import InvalidHashError,VerificationError
from cryptography.fernet import Fernet,InvalidToken
from dotenv import load_dotenv,set_key
from pwinput import pwinput
PRIVATE_MODE=384
def app_dir():
	'Return the directory the vault lives in, independent of the cwd.\n\n    A frozen build must be anchored to the executable, because __file__ then\n    points inside the temporary extraction directory rather than next to the\n    binary the user actually ran.\n    '
	if getattr(sys,'frozen',_B):return os.path.dirname(os.path.abspath(sys.executable))
	return os.path.dirname(os.path.abspath(__file__))
APP_DIR=app_dir()
DB_PATH=os.path.join(APP_DIR,'app.db')
SETTINGS_DIR=os.path.join(APP_DIR,'_settings')
ENV_PATH=os.path.join(SETTINGS_DIR,'settings.env')
KEY_PATH=os.path.join(SETTINGS_DIR,'.key')
KEY_BACKUP_PATH=os.path.join(SETTINGS_DIR,'.key.bak')
ADMIN_USERNAME_VAR='ADMIN_USERNAME'
ADMIN_PASSWORD_VAR='ADMIN_PASSWORD'
ASK_USERNAME='Enter your administrator username: '
ASK_PASSWORD='Enter your administrator password: '
COMMANDS=['exit',_C,_D,_E,_F,_G]
VERSION='v0.0.4'
SELECT_IDS='SELECT idKey, keyUser, details FROM keys'
SELECT_ALL='SELECT idKey, keyUser, details, key FROM keys'
ACCESS_DENIED='Access denied.'
hasher=PasswordHasher(time_cost=3,memory_cost=65536,parallelism=4)
KEY_LOST_HELP='The vault key in {path} does not match the one used to encrypt this\nsecret. The ciphertext in app.db cannot be decrypted without the\noriginal key -- there is no way to derive it. If the key was replaced\nor lost, restore the original file (or a copy of it) and try again.'
def hash_password(password):return hasher.hash(password)
def verify_password(stored_hash,password):
	A=stored_hash
	if not A or not isinstance(A,str):return _B
	try:hasher.verify(A,password);return True
	except(VerificationError,InvalidHashError):return _B
def read_key(path):
	with open(path,'rb')as A:return A.read()
def restrict(path):
	'Keep a vault file readable only by its owner.'
	try:os.chmod(path,PRIVATE_MODE)
	except OSError:0
def write_key(path,key):
	A=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_TRUNC,PRIVATE_MODE)
	with os.fdopen(A,'wb')as B:B.write(key)
	restrict(path)
def key_from(path):
	'Return a Fernet for path, or None if it is absent or unusable.'
	try:return Fernet(read_key(path))
	except(OSError,ValueError,TypeError):return
def load_encrypter():
	'Return a Fernet for the vault key without ever destroying a usable one.\n\n    FIX 1. A key is generated only when neither the primary nor the backup\n    exists. An existing primary is always preferred, so the vault key is\n    stable across restarts and stored secrets stay readable.\n    ';os.makedirs(SETTINGS_DIR,exist_ok=True);A=key_from(KEY_PATH)
	if A is not _A:restrict(KEY_PATH);restrict(KEY_BACKUP_PATH);return A
	if os.path.exists(KEY_PATH):print(f"Warning: {KEY_PATH} is not a readable Fernet key.")
	A=key_from(KEY_BACKUP_PATH)
	if A is not _A:write_key(KEY_PATH,read_key(KEY_BACKUP_PATH));print(f"Restored the vault key from {KEY_BACKUP_PATH}.");return A
	if os.path.exists(KEY_PATH):sys.exit(f"{KEY_PATH} exists but is not a valid key, and no usable backup\nexists at {KEY_BACKUP_PATH}.\nRefusing to generate a new key, because that would make every\nsecret in {DB_PATH} permanently undecryptable. Restore the\noriginal key file and start again.")
	B=Fernet.generate_key();write_key(KEY_PATH,B);write_key(KEY_BACKUP_PATH,B);return Fernet(B)
def decrypt_secret(encrypter,token):
	try:return encrypter.decrypt(token.encode()).decode()
	except InvalidToken:sys.exit('\n'+KEY_LOST_HELP.format(path=KEY_PATH))
def create_schema(conn):conn.execute('\n        CREATE TABLE IF NOT EXISTS keys (\n            idKey   INTEGER PRIMARY KEY AUTOINCREMENT,\n            keyUser VARCHAR(100) NOT NULL,\n            details TEXT,\n            key     VARCHAR(255) NOT NULL\n        )\n        ');conn.commit()
def authenticate(username_hash,password_hash):A=input(ASK_USERNAME);B=pwinput(prompt=ASK_PASSWORD);return verify_password(username_hash,A)and verify_password(password_hash,B)
def cmd_new_key(cur,conn,encrypter):
	A=input("Enter the key's owner's name: ").strip()
	if not A:print('The owner cannot be blank; nothing was saved.');return
	if len(A)>100:print('The owner cannot exceed 100 characters; nothing was saved.');return
	C=input('Enter the details of said key (not necessary): ').strip()or _A;B=pwinput(prompt='Enter your key: ',mask='*')
	if not B:print('The key cannot be blank; nothing was saved.');return
	cur.execute('INSERT INTO keys(keyUser, details, key) VALUES(?, ?, ?)',(A,C,encrypter.encrypt(B.encode()).decode()));conn.commit();print('Saved.')
def cmd_view_key(cur,encrypter):
	A=parse_key_id('Key ID: ')
	if A is _A:return
	cur.execute('SELECT key FROM keys WHERE idKey = ?',(A,));B=cur.fetchone()
	if B is _A:print(_H);return
	print(decrypt_secret(encrypter,B[0]))
def describe(key_id,owner,details):A=details;B=f"[{key_id}] {owner}";return f"{B} ({A})"if A else B
def cmd_delete_key(cur,conn):
	A=cur;A.execute(SELECT_IDS);C=A.fetchall()
	if not C:print('There are no keys to delete.');return
	for(B,E,F)in C:print(describe(B,E,F))
	B=parse_key_id('Enter the key you want to delete: ')
	if B is _A:return
	A.execute('SELECT keyUser FROM keys WHERE idKey = ?',(B,));D=A.fetchone()
	if D is _A:print(_H);return
	G=input(f"Delete the key owned by {D[0]!r}? [y/N] ").strip().lower()
	if G not in('y','yes'):print('Aborted; nothing was deleted.');return
	A.execute('DELETE FROM keys WHERE idKey = ?',(B,));conn.commit();print('Deleted.')
def cmd_view_all(cur,encrypter):
	cur.execute(SELECT_ALL);A=cur.fetchall()
	if not A:print('There are no keys to show.');return
	for(B,C,D,E)in A:print(describe(B,C,D));print(f"    {decrypt_secret(encrypter,E)}")
def parse_key_id(prompt):
	A=input(prompt).strip()
	try:return int(A)
	except ValueError:print(f"{A!r} is not a valid key ID.");return
def main():
	D=sqlite3.connect(DB_PATH);restrict(DB_PATH);E=D.cursor();F=load_encrypter();load_dotenv(ENV_PATH);restrict(ENV_PATH);A=os.getenv(ADMIN_USERNAME_VAR);B=os.getenv(ADMIN_PASSWORD_VAR);create_schema(D)
	if A is _A or B is _A:G=input(ASK_USERNAME);H=pwinput(prompt=ASK_PASSWORD);A=hash_password(G);B=hash_password(H);set_key(ENV_PATH,ADMIN_USERNAME_VAR,A);set_key(ENV_PATH,ADMIN_PASSWORD_VAR,B);restrict(ENV_PATH)
	try:
		while True:
			print(f"\n{", ".join(COMMANDS)}\n");C=input('Enter your command: ')
			if C=='exit':break
			elif C==_C:
				if authenticate(A,B):cmd_new_key(E,D,F)
				else:print(ACCESS_DENIED)
			elif C==_D:
				if authenticate(A,B):cmd_view_key(E,F)
				else:print(ACCESS_DENIED)
			elif C==_E:
				if authenticate(A,B):cmd_delete_key(E,D)
				else:print(ACCESS_DENIED)
			elif C==_F:print(VERSION)
			elif C==_G:
				if authenticate(A,B):cmd_view_all(E,F)
				else:print(ACCESS_DENIED)
			else:print('Command was not recognized. Try with another one.')
	except(KeyboardInterrupt,EOFError):print()
	finally:D.close()
if __name__=='__main__':main()
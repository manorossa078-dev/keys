#!/usr/bin/env python3
import sqlite3
from pwinput import pwinput
conn=sqlite3.connect('app.db')
cur=conn.cursor()
CMDS=['exit','newKey','viewKey']
cur.execute('\nCREATE TABLE IF NOT EXISTS keys(\n    idKey INTEGER PRIMARY KEY AUTOINCREMENT,\n    keyUser VARCHAR(100) NOT NULL,\n    details TEXT,\n    key VARCHAR(255) NOT NULL\n)\n')
conn.commit()
while True:
	print(CMDS);cmd=input('Enter your command: ')
	if cmd==CMDS[0]:break
	elif cmd==CMDS[1]:username=input("Enter the key's owner's name: ");details=input('Enter the details of said key (not necessary): ');key=pwinput('Enter your key: ');cur.execute('INSERT INTO keys(keyUser, details, key) VALUES(?, ?, ?)',(username,details,key));conn.commit()
	elif cmd==CMDS[2]:
		verifyID=int(input('Enter your ID: '));cur.execute('SELECT idKey FROM keys');ids=[A[0]for A in cur.fetchall()]
		if verifyID in ids:cur.execute('SELECT key FROM keys WHERE idKey = ?',(verifyID,));print(cur.fetchone()[0])
		else:print('ID not found.')
	else:print('Command was not recognized. Try with another one.')
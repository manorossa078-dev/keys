#!/usr/bin/env python3
_B='ID not found.'
_A=None
import os,sqlite3,sys
from getpass import getpass
from argon2 import PasswordHasher
from argon2.exceptions import VerifyMismatchError
from cryptography.fernet import Fernet,InvalidToken
from dotenv import load_dotenv,set_key
from pwinput import pwinput
DB_PATH='app.db'
ENV_PATH='.settings/settings.env'
KEY_PATH='.settings/.key'
KEY_BACKUP_PATH='.settings/.key.bak'
SETTINGS_DIR=os.path.dirname(KEY_PATH)
ADMIN_USERNAME_VAR='ADMIN_USERNAME'
ADMIN_PASSWORD_VAR='ADMIN_PASSWORD'
ASK_USERNAME='Enter your administrator username: '
ASK_PASSWORD='Enter your administrator password: '
COMMANDS=['exit','newKey','viewKey','deleteKey','version','viewAll']
VERSION='v0.0.3'
SELECT_ALL='SELECT * FROM keys'
ACCESS_DENIED='Access denied.'
hasher=PasswordHasher(time_cost=3,memory_cost=65536,parallelism=4)
KEY_LOST_HELP='The vault key in {path} does not match the one used to encrypt this\nsecret. The ciphertext in app.db cannot be decrypted without the\noriginal key -- there is no way to derive it. If the key was replaced\nor lost, restore the original file (or a copy of it) and try again.'
def hash_password(password):return hasher.hash(password)
def verify_password(stored_hash,password):
	try:hasher.verify(stored_hash,password);return True
	except VerifyMismatchError:return False
def read_key(path):
	with open(path,'rb')as A:return A.read()
def write_key(path,key):
	with open(path,'wb')as A:A.write(key)
def key_from(path):
	'Return a Fernet for path, or None if it is absent or unusable.'
	try:return Fernet(read_key(path))
	except(OSError,ValueError,TypeError):return
def load_encrypter():
	'Return a Fernet for the vault key without ever destroying a usable one.\n\n    FIX 1. A key is generated only when neither the primary nor the backup\n    exists. An existing primary is always preferred, so the vault key is\n    stable across restarts and stored secrets stay readable.\n    ';os.makedirs(SETTINGS_DIR,exist_ok=True);A=key_from(KEY_PATH)
	if A is not _A:return A
	if os.path.exists(KEY_PATH):print(f"Warning: {KEY_PATH} is not a readable Fernet key.")
	A=key_from(KEY_BACKUP_PATH)
	if A is not _A:write_key(KEY_PATH,read_key(KEY_BACKUP_PATH));print(f"Restored the vault key from {KEY_BACKUP_PATH}.");return A
	if os.path.exists(KEY_PATH):sys.exit(f"{KEY_PATH} exists but is not a valid key, and no usable backup\nexists at {KEY_BACKUP_PATH}.\nRefusing to generate a new key, because that would make every\nsecret in {DB_PATH} permanently undecryptable. Restore the\noriginal key file and start again.")
	B=Fernet.generate_key();write_key(KEY_PATH,B);write_key(KEY_BACKUP_PATH,B);return Fernet(B)
def decrypt_secret(encrypter,token):
	try:return encrypter.decrypt(token.encode()).decode()
	except InvalidToken:sys.exit('\n'+KEY_LOST_HELP.format(path=KEY_PATH))
def create_schema(conn):conn.execute('\n        CREATE TABLE IF NOT EXISTS keys (\n            idKey   INTEGER PRIMARY KEY AUTOINCREMENT,\n            keyUser VARCHAR(100) NOT NULL,\n            details TEXT,\n            key     VARCHAR(255) NOT NULL\n        )\n        ');conn.commit()
def authenticate(root_username,root_password):A=input(ASK_USERNAME);B=getpass(ASK_PASSWORD);return verify_password(root_username,A)and verify_password(root_password,B)
def cmd_new_key(cur,conn,encrypter):A=input("Enter the key's owner's name: ");B=input('Enter the details of said key (not necessary): ')or _A;C=pwinput(prompt='Enter your key: ',mask='*');cur.execute('INSERT INTO keys(keyUser, details, key) VALUES(?, ?, ?)',(A,B,encrypter.encrypt(C.encode()).decode()));conn.commit()
def cmd_view_key(cur,encrypter):
	A=parse_key_id('Key ID: ')
	if A is _A:return
	cur.execute('SELECT key FROM keys WHERE idKey = ?',(A,));B=cur.fetchone()
	if B is _A:print(_B);return
	print(decrypt_secret(encrypter,B[0]))
def cmd_delete_key(cur,conn):
	A=cur;A.execute(SELECT_ALL);C=A.fetchall();print(C)
	if not C:print('There are no keys to delete.');return
	B=parse_key_id('Enter the key you want to delete: ')
	if B is _A:return
	A.execute('SELECT keyUser FROM keys WHERE idKey = ?',(B,));D=A.fetchone()
	if D is _A:print(_B);return
	E=input(f"Delete the key owned by {D[0]!r}? [y/N] ").strip().lower()
	if E not in('y','yes'):print('Aborted; nothing was deleted.');return
	A.execute('DELETE FROM keys WHERE idKey = ?',(B,));conn.commit();print('Deleted.')
def cmd_view_all(cur):cur.execute(SELECT_ALL);print(cur.fetchall())
def parse_key_id(prompt):
	A=input(prompt).strip()
	try:return int(A)
	except ValueError:print(f"{A!r} is not a valid key ID.");return
def main():
	B=sqlite3.connect(DB_PATH);C=B.cursor();F=load_encrypter();load_dotenv(ENV_PATH);D=os.getenv(ADMIN_USERNAME_VAR);E=os.getenv(ADMIN_PASSWORD_VAR);create_schema(B)
	if D is _A:G=input(ASK_USERNAME);H=pwinput(prompt=ASK_PASSWORD);set_key(ENV_PATH,ADMIN_USERNAME_VAR,hash_password(G));set_key(ENV_PATH,ADMIN_PASSWORD_VAR,hash_password(H))
	while True:
		print(f"\n{COMMANDS}\n");A=input('Enter your command: ')
		if A==COMMANDS[0]:break
		elif A==COMMANDS[1]:cmd_new_key(C,B,F)
		elif A==COMMANDS[2]:
			if authenticate(D,E):cmd_view_key(C,F)
			else:print(ACCESS_DENIED)
		elif A==COMMANDS[3]:
			if authenticate(D,E):cmd_delete_key(C,B)
			else:print(ACCESS_DENIED)
		elif A==COMMANDS[4]:print(VERSION)
		elif A==COMMANDS[5]:
			if authenticate(D,E):cmd_view_all(C)
			else:print(ACCESS_DENIED)
		else:print('Command was not recognized. Try with another one.')
if __name__=='__main__':main()